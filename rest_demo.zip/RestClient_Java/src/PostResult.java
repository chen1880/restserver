import net.sf.json.JSONArray;

public class PostResult {
	public boolean IsSuccess = false;
    public String Info = "";
    public String Err = "";
    public String Des = "";
    public JSONArray Data = null;
}
