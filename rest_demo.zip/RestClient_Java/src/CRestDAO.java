import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import encryption.SecurityHelper;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class CRestDAO {
	
	private static class RestStoreHolder {
        static CRestDAO instance = new CRestDAO();
    }

    public static CRestDAO getInstance() {
        return RestStoreHolder.instance;
    }
    
    private String strUrl = "";
    
    public void SetUrl(String url)
    {
    	strUrl = url;
    }
    
    PostResult HttpPost(String method, String strcontent) {
        
    	PostResult ret = new PostResult();
    	
    	String jsonBack = "";
        
        try {
	        URL url = new URL(strUrl + method);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoOutput(true);
	        connection.setDoInput(true);
	        connection.setRequestMethod("POST");
	        connection.setUseCaches(false);
	        connection.setInstanceFollowRedirects(true);
	        connection.setRequestProperty("Content-Type", "application/json");
	        connection.setConnectTimeout(10000);
	        connection.setReadTimeout(10000);
	        connection.connect();
	
	        OutputStream os = connection.getOutputStream(); 
	        os.write(strcontent.getBytes("UTF-8")); 
	        os.close(); 
	        
	        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = in.readLine()) != null) {
	        	jsonBack += line;
	        }
	        
	        jsonBack = jsonBack.replaceAll("\\\\","");
    		jsonBack = jsonBack.substring(1, jsonBack.length() - 1);
    		JSONObject jsonInfo = JSONObject.fromObject(jsonBack);
    		if (jsonInfo.containsKey("code")) 
    		{
    			if (0 == (Integer)jsonInfo.get("code")) ret.IsSuccess = true;
    			ret.Info = (String) jsonInfo.get("info");
    			ret.Err = (String) jsonInfo.get("err");
    			ret.Data = (JSONArray)jsonInfo.get("data");
    		}
        }
        catch (IOException ex) {
        	ret.Err = ex.getMessage();
        	System.out.println("IOException:" + ret.Err);
        } 
        return ret;
    }
    
    public PostResult Test()
    {
    	return HttpPost("Test", "");
    }
    
    public PostResult MultiParam(String strParam1, String strParam2)
    {
        String strJson = "{\"strParam1\":\"" + strParam1 + "\",\"strParam2\":\"" + strParam2 + "\"}";
        return HttpPost("MultiParam", strJson);
    }
    
    public PostResult GetDataTable(String strSql)
    {
    	String strJson = "{\"strSql\":\"" + strSql + "\"}";
        return HttpPost("GetDataTable", strJson);
    }
    
    public PostResult GetDataTable_DES(String strSql)
    {
        // ����
        strSql = SecurityHelper.EncryptDES(SecurityHelper.key, strSql);
        String strJson = "{\"strSql\":\"" + strSql + "\"}";
        PostResult ret = HttpPost("GetDataTable_DES", strJson);
        // ����
        ret.Des = ret.Info;
        ret.Info = SecurityHelper.DecryptDES(SecurityHelper.key, ret.Info);
        return ret;
    }

    public PostResult ExecuteNonQuery(String strSql)
    {
    	String strJson = "{\"strSql\":\"" + strSql + "\"}";
        return HttpPost("ExecuteNonQuery", strJson);
    }

    public PostResult ExecuteNonQuery_DES(String strSql)
    {
        // ����
        strSql = SecurityHelper.EncryptDES(SecurityHelper.key, strSql);
        String strJson = "{\"strSql\":\"" + strSql + "\"}";
        PostResult ret = HttpPost("ExecuteNonQuery_DES", strJson);
        // ����
        ret.Des = ret.Info;
        ret.Info = SecurityHelper.DecryptDES(SecurityHelper.key, ret.Info);
        return ret;
    }
}
